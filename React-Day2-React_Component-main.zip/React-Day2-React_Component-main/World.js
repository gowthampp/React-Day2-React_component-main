import React from 'react'

function World() {
  return (
    <div><p>This Is World Functional Component</p></div>
  )
}

export default World